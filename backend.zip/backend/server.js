require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const { initializeDatabase, db } = require('./database');
const auth = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware - Allow all origins for development
app.use(cors({
  origin: true, // Allow all origins in development
  credentials: true
}));
app.use(express.json());

// Add this after your middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Serve static files (your frontend)
// Serve static files (your frontend)
app.use(express.static(__dirname));

// Serve the main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Initialize database
initializeDatabase();

// Auth routes
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password, monthly_income, savings_goal } = req.body;
    
    // Check if user exists
    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
      if (err) return res.status(500).json({ error: err.message });
      if (user) return res.status(400).json({ error: 'User already exists' });

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Insert user
      db.run(
        `INSERT INTO users (username, email, password, monthly_income, savings_goal) 
         VALUES (?, ?, ?, ?, ?)`,
        [username, email, hashedPassword, monthly_income, savings_goal],
        function(err) {
          if (err) return res.status(500).json({ error: err.message });
          
          // Generate token
          const token = jwt.sign({ userId: this.lastID }, process.env.JWT_SECRET || 'fallback_secret');
          
          res.status(201).json({
            message: 'User created successfully',
            token,
            user: { id: this.lastID, username, email, monthly_income, savings_goal }
          });
        }
      );
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    
    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid credentials' });
    
    // Generate token
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET || 'fallback_secret');
    
    res.json({
      message: 'Logged in successfully',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        monthly_income: user.monthly_income,
        savings_goal: user.savings_goal
      }
    });
  });
});

// Protected routes
app.get('/api/user', auth, (req, res) => {
  db.get('SELECT id, username, email, monthly_income, savings_goal FROM users WHERE id = ?', [req.userId], (err, user) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });
});

// Expenses routes
app.get('/api/expenses', auth, (req, res) => {
  db.all('SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC', [req.userId], (err, expenses) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(expenses);
  });
});

app.post('/api/expenses', auth, (req, res) => {
  const { name, amount, category, date } = req.body;
  
  db.run(
    'INSERT INTO expenses (user_id, name, amount, category, date) VALUES (?, ?, ?, ?, ?)',
    [req.userId, name, amount, category, date || new Date().toISOString()],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      
      db.get('SELECT * FROM expenses WHERE id = ?', [this.lastID], (err, expense) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json(expense);
      });
    }
  );
});

app.delete('/api/expenses/:id', auth, (req, res) => {
  db.run('DELETE FROM expenses WHERE id = ? AND user_id = ?', [req.params.id, req.userId], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Expense deleted successfully' });
  });
});

// User settings
app.put('/api/user/settings', auth, (req, res) => {
  const { monthly_income, savings_goal, openai_key } = req.body;
  
  db.run(
    'UPDATE users SET monthly_income = ?, savings_goal = ?, openai_key = ? WHERE id = ?',
    [monthly_income, savings_goal, openai_key, req.userId],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Settings updated successfully' });
    }
  );
});

app.get('/api/stats', auth, (req, res) => {
  // Get user data and expense stats
  db.get('SELECT monthly_income, savings_goal FROM users WHERE id = ?', [req.userId], (err, user) => {
    if (err) return res.status(500).json({ error: err.message });
    
    db.all(
      `SELECT category, SUM(amount) as total 
       FROM expenses 
       WHERE user_id = ? AND date >= date('now','start of month') 
       GROUP BY category`,
      [req.userId],
      (err, categoryTotals) => {
        if (err) return res.status(500).json({ error: err.message });
        
        const totalExpenses = categoryTotals.reduce((sum, cat) => sum + cat.total, 0);
        const saved = Math.max(0, (user.monthly_income || 0) - totalExpenses);
        const goalPercentage = user.savings_goal > 0 ? Math.min(100, (saved / user.savings_goal) * 100) : 0;
        
        res.json({
          monthly_income: user.monthly_income,
          savings_goal: user.savings_goal,
          total_expenses: totalExpenses,
          saved_amount: saved,
          goal_percentage: goalPercentage,
          category_totals: categoryTotals
        });
      }
    );
  });
});


app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser`);
});